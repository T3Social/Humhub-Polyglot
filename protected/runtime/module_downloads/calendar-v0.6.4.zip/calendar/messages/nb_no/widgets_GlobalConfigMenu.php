<?php
return array (
  'Defaults' => 'Standard innstillinger',
  'Event Types' => 'Aktivitetstyper',
  'Snippet' => 'Snippet',
);
