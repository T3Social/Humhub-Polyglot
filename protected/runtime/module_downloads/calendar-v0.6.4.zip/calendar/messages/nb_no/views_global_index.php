<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtrer</strong> events',
  '<strong>Select</strong> calendars' => '<strong>Velg</strong> kalendere',
  'Already responded' => 'Allerede besvart',
  'Followed spaces' => 'Følger grupper',
  'Followed users' => 'Følger brukere',
  'I\'m attending' => 'Jeg deltar',
  'My events' => 'Mine events',
  'My profile' => 'Min profil',
  'My spaces' => 'Mine grupper',
  'Not responded yet' => 'Ikke besvart enda',
);
