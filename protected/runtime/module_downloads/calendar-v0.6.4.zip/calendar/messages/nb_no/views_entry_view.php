<?php
return array (
  'Attend' => 'Delta',
  'Decline' => 'Avvis',
  'Maybe' => 'Kanskje',
  'Participant information:' => 'Deltaker informasjon:',
  'Read full description...' => 'Les hele beskrivelsen...',
  'Read full participation info...' => 'Les hele deltaker informasjonen...',
);
