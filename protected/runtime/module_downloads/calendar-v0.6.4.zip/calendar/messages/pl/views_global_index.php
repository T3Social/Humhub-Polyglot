<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtruj</strong> wydarzenia',
  '<strong>Select</strong> calendars' => '<strong>Wybierz</strong> kalendarze',
  'Already responded' => 'Już odpowiedzieli',
  'Followed spaces' => 'Obserwowane strefy',
  'Followed users' => 'Obserwowani użytkownicy',
  'I\'m attending' => 'Biorę udział',
  'My events' => 'Moje wydarzenia',
  'My profile' => 'Mój profil',
  'My spaces' => 'Moje strefy',
  'Not responded yet' => 'Nie odpowiedzieli jeszcze ',
);
