<?php
return array (
  ':count attending' => ':count 加者数',
  ':count declined' => ':count 参加辞退者数',
  ':count maybe' => ':count 参加未定者数',
  'Participants:' => '参加者：',
);
