<?php
return array (
  'Calendar' => 'Calendário',
  'Receive Calendar related Notifications.' => 'Receber notificações de calendário',
);
