<?php
return array (
  'Allows the user to create new calendar entries' => 'Permitir que usuários criem novas entradas de calendário',
  'Allows the user to edit/delete existing calendar entries' => 'Permitir que usuários alterem/apaguem entradas de calendário existentes',
  'Create entry' => 'Criar entrada',
  'Manage entries' => 'Administrar entradas',
);
