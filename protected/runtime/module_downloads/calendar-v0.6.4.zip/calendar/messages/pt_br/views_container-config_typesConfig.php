<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Criar</strong> novo tipo de evento',
  '<strong>Create</strong> new type' => '<strong>Criar</strong> novo tipo',
  '<strong>Edit</strong> event type' => '<strong>Alterar</strong> tipo de evento',
);
