<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% dalyvaus %contentTitle%.
',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% galbūt dalyvaus %contentTitle%.
',
  '%displayName% not attends to %contentTitle%.' => '%displayName% nedalyvaus %contentTitle%.
',
);
