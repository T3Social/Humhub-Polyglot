<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Aankomende</strong> gebeurtenissen ',
  'Open Calendar' => 'Open agenda',
);
