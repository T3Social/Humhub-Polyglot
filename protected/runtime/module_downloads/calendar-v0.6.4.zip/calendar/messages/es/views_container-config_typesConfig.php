<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Crear</strong> nuevo tipo de evento',
  '<strong>Create</strong> new type' => '<strong>Crear</strong> nuevo tipo',
  '<strong>Edit</strong> event type' => '<strong>Editar</strong> tipo de evento',
);
