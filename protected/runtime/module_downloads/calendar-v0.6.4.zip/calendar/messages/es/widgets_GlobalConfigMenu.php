<?php
return array (
  'Defaults' => 'Valores por defecto',
  'Event Types' => 'Tipos de evento',
  'Snippet' => 'Snippet',
);
