<?php
return array (
  '<strong>Create</strong> event' => '<strong>Crear</strong> evento',
  '<strong>Edit</strong> event' => '<strong>Editar</strong> evento',
  'Basic' => 'Básico',
  'Everybody can participate' => 'Todo el mundo puede participar',
  'Files' => 'Archivos',
  'No participants' => 'Sin participantes',
  'Participation' => 'Participación',
  'Select event type...' => 'Seleccionar tipo de evento...',
  'Title' => 'Título',
);
