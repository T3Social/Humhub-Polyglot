<?php
return array (
  'Defaults' => 'Predefinite',
  'Event Types' => 'Tipi di evento',
  'Snippet' => 'Snippet',
);
