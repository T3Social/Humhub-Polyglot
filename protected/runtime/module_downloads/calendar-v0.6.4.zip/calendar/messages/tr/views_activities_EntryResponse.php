<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%contentTitle% etkinliğe %displayName% katıldı.',
  '%displayName% maybe attends to %contentTitle%.' => '%contentTitle% etkinliğe %displayName% belki katılıcak.',
  '%displayName% not attends to %contentTitle%.' => '%contentTitle% etkinliğe %displayName% katılmıyor.',
);
