<?php
return array (
  'Defaults' => 'Standards',
  'Event Types' => 'Kategorie',
  'Snippet' => 'Widget',
);
