<?php
return array (
  'Loading...' => 'Lädt …',
);
