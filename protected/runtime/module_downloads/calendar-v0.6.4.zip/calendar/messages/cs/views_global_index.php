<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtrovat</strong> události',
  '<strong>Select</strong> calendars' => '<strong>Vybrat</strong> kalendáře',
  'Already responded' => 'Již jste odpověl(a)',
  'Followed spaces' => 'Sledované prostory',
  'Followed users' => 'Sledovaní uživatelé',
  'I\'m attending' => 'Zúčastním se',
  'My events' => 'Moje události',
  'My profile' => 'Můj profil',
  'My spaces' => 'Moje prostory',
  'Not responded yet' => 'Zatím jste neodpověl(a)',
);
