<?php
return array (
  'Defaults' => 'Zadano',
  'Event Types' => 'Vrste događaja',
  'Snippet' => 'Isječak',
);
