<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filter</strong> događaja',
  '<strong>Select</strong> calendars' => '<strong>Odaberi</strong> kalendare',
  'Already responded' => 'Već odgovoreno',
  'Followed spaces' => 'Praćeni prostori',
  'Followed users' => 'Praćeni korisnici',
  'I´m attending' => 'Prisustvujem',
  'My events' => 'Moji događaji',
  'My profile' => 'Moj profil',
  'My spaces' => 'Moji prostori',
  'Not responded yet' => 'Još nije odgovoreno',
);
