<?php
return array (
  '<strong>Filter</strong> events' => 'Filter Acara',
  '<strong>Select</strong> calendars' => 'Pilih Kalender',
  'Already responded' => 'Sudah terespons',
  'Followed spaces' => 'Ikuti Ruang',
  'Followed users' => 'Ikuti pengguna',
  'I´m attending' => 'Saya menghadiri',
  'My events' => 'Acara Saya',
  'My profile' => 'Profil saya',
  'My spaces' => 'Ruang Saya',
  'Not responded yet' => 'Belum dapat respons',
);
