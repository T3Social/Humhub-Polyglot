<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtrer</strong> les événements',
  '<strong>Select</strong> calendars' => '<strong>Choisir</strong> les calendriers',
  'Already responded' => 'Déjà répondu',
  'Followed spaces' => 'Espaces suivis',
  'Followed users' => 'Utilisateurs suivis',
  'I\'m attending' => 'Je participe',
  'My events' => 'Mes événements',
  'My profile' => 'Mon profil',
  'My spaces' => 'Mes espaces',
  'Not responded yet' => 'Pas encore répondu',
);
