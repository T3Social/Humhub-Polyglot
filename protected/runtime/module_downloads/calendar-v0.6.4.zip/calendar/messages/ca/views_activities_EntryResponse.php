<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% assistirà a %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% potser assistirà a %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% no assistirà a %contentTitle%.',
);
