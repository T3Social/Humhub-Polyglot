<?php
return array (
  'Add answer...' => 'Añadir respuesta...',
  'Allow multiple answers per user?' => '¿Permitir multiples respuestas por usuario?',
  'Anonymous Votes?' => '¿Votos Anónimos?',
  'Ask something...' => 'Pregunta algo...',
  'Display answers in random order?' => '¿Mostrar respuestas en orden aleatorio?',
  'Edit answer (empty answers will be removed)...' => 'Editar respuesta (las respuestas vacías se eliminarán) ...',
  'Edit your poll question...' => 'Editar la pregunta de la encuesta ...',
);
