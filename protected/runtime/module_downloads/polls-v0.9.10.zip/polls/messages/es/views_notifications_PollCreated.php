<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} creó una nueva votación y la asignó a ti.',
);
