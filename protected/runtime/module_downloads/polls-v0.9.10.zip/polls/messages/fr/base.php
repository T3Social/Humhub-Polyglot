<?php
return array (
  'Allows to start polls.' => 'Autorise à lancer des sondages.',
  'Cancel' => 'Annuler',
  'Polls' => 'Sondages',
  'Save' => 'Enregistrer',
);
