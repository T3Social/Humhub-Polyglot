<?php
return array (
  'Anonymous' => 'Anonyme',
  'Closed' => 'Fermé',
  'Complete Poll' => 'Compléter le sondage',
  'Reopen Poll' => 'Réouvrir le sondage',
  'Reset my vote' => 'Annuler mon vote',
  'Vote' => 'Voter',
  'and {count} more vote for this.' => 'et {count} réponses en plus.',
  'votes' => 'réponses',
);
