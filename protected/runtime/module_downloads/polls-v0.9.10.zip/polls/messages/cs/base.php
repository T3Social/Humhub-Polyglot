<?php
return array (
  'Allows to start polls.' => 'Povolení vytváření anket',
  'Cancel' => 'Zrušit',
  'Polls' => 'Ankety',
  'Save' => 'Uložit',
);
