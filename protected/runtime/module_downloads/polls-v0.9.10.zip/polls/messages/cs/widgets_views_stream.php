<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Zatím žádné ankety!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Zatím zde nejsou žádné ankety.</b><br>Vytvořte první...',
  'Asked by me' => 'Vytvořil(a) jsem',
  'No answered yet' => 'Bez odpovědí',
  'Only private polls' => 'Jen neveřejné ankety',
  'Only public polls' => 'Jen veřejné ankety',
);
