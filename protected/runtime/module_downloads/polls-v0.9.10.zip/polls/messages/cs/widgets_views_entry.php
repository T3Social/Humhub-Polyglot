<?php
return array (
  'Anonymous' => 'Anonym',
  'Closed' => 'Uzavřeno',
  'Complete Poll' => 'Dokončit anketu',
  'Reopen Poll' => 'Znovu otevřít anketu',
  'Reset my vote' => 'Zrušit mé hlasování',
  'Vote' => 'Hlasovat',
  'and {count} more vote for this.' => 'a dalších {count} lidí pro to hlasovalo.',
  'votes' => 'hlasů',
);
