<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Atšaukti',
  'Polls' => 'Apklausos',
  'Save' => 'Išsaugoti',
);
