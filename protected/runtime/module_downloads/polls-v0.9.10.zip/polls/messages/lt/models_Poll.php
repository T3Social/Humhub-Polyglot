<?php
return array (
  'Answers' => 'Atsakymai',
  'Multiple answers per user' => 'Vieno vartotojo kelių atsakymo variantų pasirinkimas',
  'Please specify at least {min} answers!' => 'Prašome pasirinkti bent {min} atsakymą!',
  'Question' => 'Klausimas',
);
