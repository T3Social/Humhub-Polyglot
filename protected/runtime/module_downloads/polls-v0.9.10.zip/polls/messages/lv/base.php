<?php
return array (
  'Allows to start polls.' => 'Atļauj uzsākt aptauju.',
  'Cancel' => 'Atcelt',
  'Polls' => 'Aptaujas',
  'Save' => 'Saglabāt',
);
