<?php
return array (
  'Access denied!' => 'Pieeja noraidīta!',
  'Anonymous poll!' => 'Anonīma aptauja!',
  'Could not load poll!' => 'Nevarēja ielādēt aptauju!',
  'Invalid answer!' => 'Kļūdaina atbilde!',
  'Users voted for: <strong>{answer}</strong>' => 'Lietotāji nobalsoja par: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Balsošana ar vairākām atbildēm ir atslēgta!',
  'You have insufficient permissions to perform that operation!' => 'Tev nav pietiekošas pieejas lai veiktu šo darbību!',
);
