<?php
return array (
  'Add answer...' => 'Pievieno atbildi...',
  'Allow multiple answers per user?' => 'Atļaut vairākas atbildes no lietotāja?',
  'Anonymous Votes?' => 'Anonīmi balsojumi?',
  'Ask something...' => 'Pavaicā kaut ko...',
  'Display answers in random order?' => 'Parādīt atbildes jauktā kārtībā?',
  'Edit answer (empty answers will be removed)...' => 'Labot atbildi (tukšie balsojumi tiks dzēsti)...',
  'Edit your poll question...' => 'Labot savu aptaujas jautājumu...',
);
