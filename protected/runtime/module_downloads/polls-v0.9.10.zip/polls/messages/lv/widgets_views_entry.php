<?php
return array (
  'Anonymous' => 'Anonīma',
  'Closed' => 'Slēgta',
  'Complete Poll' => 'Pabeigt aptauju',
  'Reopen Poll' => 'Atkal atvērt aptauju',
  'Reset my vote' => 'Atcelt manu balsojumu',
  'Vote' => 'Balsot',
  'and {count} more vote for this.' => 'un vēl {count} citi balsoja par šo.',
  'votes' => 'balsis',
);
