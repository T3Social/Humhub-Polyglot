<?php
return array (
  'Add answer...' => 'Antwort hinzufügen...',
  'Allow multiple answers per user?' => 'Sind Mehrfachantworten zugelassen?',
  'Anonymous Votes?' => 'Anonyme Abstimmung?',
  'Ask something...' => 'Stelle eine Frage...',
  'Display answers in random order?' => 'Antworten in zufälliger Reihenfolge anzeigen?',
  'Edit answer (empty answers will be removed)...' => 'Antwort bearbeiten (leere Antworten werden entfernt)...',
  'Edit your poll question...' => 'Frage bearbeiten',
);
