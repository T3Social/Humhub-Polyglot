<?php
return array (
  'Anonymous' => 'Anonym',
  'Closed' => 'Beendet',
  'Complete Poll' => 'Abstimmung schliessen',
  'Reopen Poll' => 'Abstimmung wieder öffnen',
  'Reset my vote' => 'Meine Abstimmung zurücksetzen',
  'Vote' => 'Abstimmen',
  'and {count} more vote for this.' => 'und {count} mehr stimmten hierfür ab.',
  'votes' => 'Abstimmungen',
);
