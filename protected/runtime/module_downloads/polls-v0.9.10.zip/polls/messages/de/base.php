<?php
return array (
  'Allows to start polls.' => 'Ermöglicht Umfragen zu starten.',
  'Cancel' => 'Abbrechen',
  'Polls' => 'Umfragen',
  'Save' => 'Speichern',
);
