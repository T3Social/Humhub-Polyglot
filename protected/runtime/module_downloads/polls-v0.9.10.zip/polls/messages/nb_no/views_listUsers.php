<?php
return array (
  'User who vote this' => 'Brukere som stemte dette',
);
