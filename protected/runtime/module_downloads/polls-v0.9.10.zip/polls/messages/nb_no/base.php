<?php
return array (
  'Allows to start polls.' => 'Tillater å starte en meningsmåling.',
  'Cancel' => 'Avbryt',
  'Polls' => 'Meningsmålinger',
  'Save' => 'Lagre',
);
