<?php
return array (
  'Ask' => 'Spør',
);
