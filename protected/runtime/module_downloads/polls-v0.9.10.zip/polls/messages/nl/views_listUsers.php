<?php
return array (
  'User who vote this' => 'Gebruiker die dit stemde',
);
