<?php
return array (
  'Anonymous' => 'Anoniem',
  'Closed' => 'Gesloten',
  'Complete Poll' => 'Rond het stemmen af.',
  'Reopen Poll' => 'Heropen de stembus',
  'Reset my vote' => 'Reset mijn antwoord',
  'Vote' => 'Stem',
  'and {count} more vote for this.' => 'en {count} anderen hebben voor dit gestemd.',
  'votes' => 'stemmen',
);
