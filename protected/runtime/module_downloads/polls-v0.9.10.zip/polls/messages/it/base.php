<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Annulla',
  'Polls' => 'Sondaggi',
  'Save' => 'Salva',
);
