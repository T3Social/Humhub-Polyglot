<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Отменить',
  'Polls' => 'Опросы',
  'Save' => 'Сохранить',
);
