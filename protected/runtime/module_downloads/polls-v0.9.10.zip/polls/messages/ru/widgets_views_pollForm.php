<?php
return array (
  'Add answer...' => 'Добавить ответ ...',
  'Allow multiple answers per user?' => 'Разрешить несколько варинатов ответов пользователю?',
  'Anonymous Votes?' => 'Анонимных голосов?',
  'Ask something...' => 'Спросить как нибудь...',
  'Display answers in random order?' => 'Отображение ответов в случайном порядке?',
  'Edit answer (empty answers will be removed)...' => 'Редактировать ответ (пустые ответы будут удалены) ...',
  'Edit your poll question...' => '',
);
