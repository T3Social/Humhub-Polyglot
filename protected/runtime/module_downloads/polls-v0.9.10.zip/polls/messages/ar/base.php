<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'إلغاء',
  'Polls' => '',
  'Save' => 'حفظ',
);
