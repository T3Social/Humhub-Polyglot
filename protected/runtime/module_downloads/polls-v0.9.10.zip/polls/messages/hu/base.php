<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Mégsem',
  'Polls' => '',
  'Save' => 'Mentés',
);
