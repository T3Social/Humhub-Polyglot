<?php
return array (
  'Add answer...' => 'Thêm câu trả lời...',
  'Allow multiple answers per user?' => 'Cho phép một người chọn nhiều câu trả lời?',
  'Anonymous Votes?' => 'Cho phép biểu quyết nặc danh?',
  'Ask something...' => 'Hỏi gì đó...',
  'Display answers in random order?' => 'Hiển thị câu trả lời theo thứ tự ngẫu nhiên?',
  'Edit answer (empty answers will be removed)...' => 'Chỉnh sửa câu hỏi (câu hỏi trống sẽ bị xóa bỏ)...',
  'Edit your poll question...' => 'Chỉnh sửa câu hỏi biểu quyết...',
);
