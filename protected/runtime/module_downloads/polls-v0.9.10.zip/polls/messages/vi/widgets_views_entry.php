<?php
return array (
  'Anonymous' => 'Nặc danh',
  'Closed' => 'Đóng',
  'Complete Poll' => 'Hoàn thành biểu quyết',
  'Reopen Poll' => 'Mở lại biểu quyết',
  'Reset my vote' => 'Đặt lại phiếu của tôi',
  'Vote' => 'Bỏ phiếu',
  'and {count} more vote for this.' => 'và  thêm {count} biểu quyết cho điều này.',
  'votes' => 'bỏ phiếu',
);
