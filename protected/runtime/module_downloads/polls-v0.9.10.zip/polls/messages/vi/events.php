<?php
return array (
  'Again? ;Weary;' => 'Lại lần nữa? ;Weary;',
  'Club A Steakhouse' => 'Tiệm thịt bò?',
  'Pisillo Italian Panini' => 'Nhà hàng Ý?',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Ngay bây giờ, chúng tôi đang lên kế hoạch cho cuộc gặp tiếp theo và tôi muốn biểu quyết từ các bạn, chúng ta nên đi đâu?',
  'To Daniel' => 'Gửi Daniel',
  'Why don\'t we go to Bemelmans Bar?' => 'Sao chúng ta không đến quán bar Bemmelmans nhỉ?',
);
