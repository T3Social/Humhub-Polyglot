<?php
return array (
  '{userName} answered the {question}.' => '{userName} odpowiedział(a) na {question}.',
);
