<?php
return array (
  'Allows to start polls.' => 'Pozwala dodawać głosowania.',
  'Cancel' => 'Anuluj',
  'Polls' => 'Głosowania ',
  'Save' => 'Zapisz ',
);
