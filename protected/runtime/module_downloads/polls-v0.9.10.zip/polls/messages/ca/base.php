<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Cancel·la',
  'Polls' => 'Enquestes',
  'Save' => 'Desa',
);
