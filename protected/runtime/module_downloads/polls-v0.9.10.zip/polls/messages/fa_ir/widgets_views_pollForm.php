<?php
return array (
  'Add answer...' => 'ضافه كردن پاسخ....',
  'Allow multiple answers per user?' => 'اجازه‌ی چند پاسخ به هر کاربر داده‌شود؟',
  'Anonymous Votes?' => 'راي دهي ناشناس؟',
  'Ask something...' => 'سوال بپرس . . .',
  'Display answers in random order?' => 'نشان دادن پاسخ ها بصورت اتفاقي',
  'Edit answer (empty answers will be removed)...' => 'ويرايش پاسخ ها',
  'Edit your poll question...' => 'ويرايش سوال نظرخواهي',
);
