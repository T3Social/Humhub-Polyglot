<?php
return array (
  'Add answer...' => 'Cevap ekleyin...',
  'Allow multiple answers per user?' => 'Birden fazla cevap verilsin mi?',
  'Anonymous Votes?' => 'Misafir oy?',
  'Ask something...' => 'Bir şeyler sor...',
  'Display answers in random order?' => 'Cevapları rastgele sırala?',
  'Edit answer (empty answers will be removed)...' => '',
  'Edit your poll question...' => 'Anket sorusunu düzenle...',
);
