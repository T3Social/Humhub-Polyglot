<?php
return array (
  '{userName} created a new {question}.' => '{userName} yeni bir soru sordu {question}.',
);
