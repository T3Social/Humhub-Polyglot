<?php
return array (
  'Access denied!' => 'Akses ditolak!',
  'Anonymous poll!' => '',
  'Could not load poll!' => 'Tidak dapat memuat pemungutan suara!',
  'Invalid answer!' => 'Jawaban tidak valid!',
  'Users voted for: <strong>{answer}</strong>' => 'Pengguna memilih: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Voting untuk beberapa jawaban dinon-aktifkan!',
  'You have insufficient permissions to perform that operation!' => 'Anda tidak memiliki izin yang memadai untuk melakukan operasi itu!',
);
