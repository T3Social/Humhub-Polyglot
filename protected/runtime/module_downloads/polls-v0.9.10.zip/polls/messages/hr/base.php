<?php
return array (
  'Allows to start polls.' => 'Dopusti polls',
  'Cancel' => 'poništi',
  'Polls' => 'Polls',
  'Save' => 'Spremi',
);
